let demo = function() {
    console.log('This is v1.0.1 of the demo package');
}

module.exports = {
    demo : demo
}
